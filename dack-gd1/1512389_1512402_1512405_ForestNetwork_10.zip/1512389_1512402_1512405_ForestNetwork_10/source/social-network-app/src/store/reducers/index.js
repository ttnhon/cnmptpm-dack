import { combineReducers } from "redux";
import followingReducer from './followingReducer';

import auth from "./auth";

export default combineReducers({
  //following: followingReducer
});
