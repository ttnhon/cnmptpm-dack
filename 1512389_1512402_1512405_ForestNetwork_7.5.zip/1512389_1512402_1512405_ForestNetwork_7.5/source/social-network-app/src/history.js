import createHistory from 'history/createBrowserHistory';

//create history
const history = createHistory();

export default history;